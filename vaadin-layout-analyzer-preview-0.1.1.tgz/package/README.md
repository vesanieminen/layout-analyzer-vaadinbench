# Vaadin layout analyzer — preview 0.1.1

Capture a running Vaadin application's rendered layout as Markdown and JSON for a coding agent. No Copilot checkout, custom Copilot build, backend patch or model service is required. The target application must run in development mode with Copilot available.

Verified against **Vaadin / Copilot 25.3.0-beta3**, Flow, Aura, Chromium. Other versions, themes and Hilla are not yet verified. This uses internal Copilot runtime APIs through a small adapter; it is an evaluation preview, not a supported extension API.

## Install in an existing project or benchmark runner

Requires Node 22 or newer. The package is distributed as a tarball, not published to npm.

```sh
npm install --save-dev /path/to/vaadin-layout-analyzer-preview-0.1.1.tgz
npx playwright install chromium
npx vaadin-layout-analyze http://localhost:8080/your-route --out layout-report
```

Start the Vaadin application normally. The CLI creates `layout-report/layout.md` and `layout-report/layout.json`. It does not change application source or require adding a Java dependency. `--width 720 --height 900` captures another viewport; use a separate output directory to keep both. Existing files in the output directory are overwritten.

For an agent or a pipeline, use `--stdout` to emit only Markdown, with no report files or success message. Errors go to stderr and return a nonzero exit status. `--stdout` and `--out` are mutually exclusive.

```sh
npm exec --yes --package=/path/to/vaadin-layout-analyzer-preview-0.1.1.tgz -- \
  vaadin-layout-analyze http://localhost:8080/your-route --stdout
```

The explicit tarball form also works when the package is not installed in the app's `node_modules`.

For an already installed Chromium, set `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` to its executable path. The browser bundle is included in the tarball; consumers do not need to build it.

## Benchmark integration

Use your existing Playwright page to control authentication, data, state and viewport. Wait for the task's actual readiness condition before capturing.

```js
import { captureLayout } from '@vaadin/layout-analyzer-preview/playwright';
import { writeFile } from 'node:fs/promises';

// Navigate, sign in and prepare the task using your existing benchmark setup.
await page.goto('http://localhost:8080/customer');
await page.getByLabel('Customer name').waitFor();

const report = await captureLayout(page);
await writeFile('layout.md', report.markdown);
await writeFile('layout.json', JSON.stringify(report, null, 2));

// Give report.markdown to the agent along with its ordinary task and tools.
// After an edit or state change, call captureLayout(page) again for fresh data.
```

`captureLayout` temporarily activates Copilot Inspect mode and restores the previous mode on completion or failure. It does not select tabs, fill fields, resize the page or write files. Capture a page sequentially; use separate pages for parallel tasks.

Options:

- `includeRelationships: false`: omit the new repeated-section summaries for an existing-report control. Default true.
- `timeoutMs`: Copilot startup / tree wait, default 30 seconds per wait.
- `settleTimeoutMs`: bounded geometry/font settling, default 3 seconds. A timeout is recorded in `coverage`, not silently treated as success.
- `maxReportChars`: Markdown limit, default 24,000 characters (not tokens), minimum 1,000. Truncation is stated in the text and `reportTruncated`; complete measured boxes, findings and relationships remain in JSON.

The result contains `schemaVersion`, `analyzerVersion`, `model`, `relationships`, `coverage`, `markdown`, `reportTruncated` and `durationMs`. Timing covers readiness, injection, settling and report generation before restoring the previous Copilot mode.

The core `analyze`, `formatLayoutAnalysis` and `relationships` functions are also exported from `@vaadin/layout-analyzer-preview`. They operate on plain data without a browser, allowing replay of stored captures.

## What to evaluate first

Compare the same tasks and normal browser/screenshot tools with (1) no report, (2) report with relationships disabled, and (3) the default report. Judge the resulting layout and harmful edits, not the number of warnings. Record viewport, UI state, package version, coverage, report size and task outcome. Keep this preview's fixture views out of the held-out benchmark.

The report includes measured component geometry, spacing strips, heuristic findings and a bounded set of structural peer comparisons. Repeated-section summaries can expose whole-token mistakes, such as four body insets of 16px and one of 0px. They state witnesses and exceptions; shared structure does not establish design intent. Balanced cohorts are not forced into a majority, and normal relationships remain visible.

## Limitations

- Released Copilot 25.3.0-beta3 does not supply the source-line field added in the development branch. Reports use component/tree paths and explicitly count available source references. Geometry does not require that backend change.
- Only the current view, viewport and rendered state are measured. Hidden tab/panel content is not inspected. Capture each relevant state yourself.
- Three unchanged geometry samples are not proof that async application work has finished. The caller owns readiness; inspect `coverage`.
- Heuristic warnings can describe intentional designs. The good fixture deliberately retains observations about ellipsis, spacing and free space. Do not blindly apply suggested fixes.
- Reachability and clipping remain approximate, especially nested scrollers, RTL, overlays and transforms. Four-side containment is checked; full directional scroll reachability is not yet implemented.
- Relationship matching is a conservative structural experiment, not semantic knowledge. Insets currently use physical left edges. No claim of RTL or arbitrary wrapper invariance.
- No standalone Copilot panel or automatic MCP registration in this preview. The Playwright API is the integration surface for an eval harness or future MCP tool.

## Develop and reproduce

```sh
npm ci
npm test
npm run build
npm pack
```

With the accompanying fixture app running on port 8090:

```sh
npx playwright install chromium
node test/smoke.mjs
```

Set `LAYOUT_TEST_URL` to change the origin. The smoke test captures three fixtures at 1280 and 720 pixels, checks known defects and intentional counterexamples, verifies recapture after a change and exercises the report control. Reports and screenshots go under `reports/`.

The original analyzer and regression tests were extracted from the Apache-2.0 Copilot module. This package builds and tests without its source checkout. The copied core fixes also remain in the development branch; the package is the shareable preview snapshot.
